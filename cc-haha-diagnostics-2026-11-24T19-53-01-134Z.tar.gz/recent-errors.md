# cc-haha recent diagnostics

Generated: 2026-11-24T19:53:01.148Z
Events included: 50

## 2026-11-24T19:50:57.967Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/sessions",
  "durationMs": 13924.1,
  "fetchMs": 13923.7,
  "responseReadMs": 0.3,
  "responseChars": 3710,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-6ftck-19810",
  "serverAppMs": 11.9,
  "declaredBytes": 3838,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:50:57.962Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/scheduled-tasks",
  "durationMs": 14047.9,
  "fetchMs": 14045.6,
  "responseReadMs": 2.2,
  "responseChars": 12,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-6ftck-19809",
  "serverAppMs": 0.9,
  "declaredBytes": 12,
  "suppressedSinceLast": 1
}
```

## 2026-11-24T19:50:57.961Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/session-collaboration/:id/delegation",
  "durationMs": 18324.6,
  "fetchMs": 18324.1,
  "responseReadMs": 0.5,
  "responseChars": 1487,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-6ftck-19808",
  "serverAppMs": 1.4,
  "declaredBytes": 1523,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:50:57.960Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/teams/session/:id/plan",
  "durationMs": 18322.6,
  "fetchMs": 18317.9,
  "responseReadMs": 4.6,
  "responseChars": 25610,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-6ftcf-19807",
  "serverAppMs": 1.6,
  "declaredBytes": 25752,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:50:25.407Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/teams/session/:id/plan",
  "durationMs": 5767.4,
  "fetchMs": 5767,
  "responseReadMs": 0.4,
  "responseChars": 25610,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-6f48m-19793",
  "serverAppMs": 1.7,
  "declaredBytes": 25752,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:50:25.406Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/session-collaboration/:id/delegation",
  "durationMs": 5765.2,
  "fetchMs": 5764.9,
  "responseReadMs": 0.3,
  "responseChars": 1487,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-6f48m-19794",
  "serverAppMs": 0.8,
  "declaredBytes": 1523,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:48:16.663Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/sessions",
  "durationMs": 2628,
  "fetchMs": 2627.7,
  "responseReadMs": 0.3,
  "responseChars": 3710,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-6ccw0-19648",
  "serverAppMs": 16.5,
  "declaredBytes": 3838,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:48:16.653Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/session-collaboration/:id/delegation",
  "durationMs": 5015.5,
  "fetchMs": 5014.9,
  "responseReadMs": 0.6,
  "responseChars": 1487,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-6ccw0-19646",
  "serverAppMs": 1.2,
  "declaredBytes": 1523,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:48:16.653Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/scheduled-tasks",
  "durationMs": 2745.1,
  "fetchMs": 2744.4,
  "responseReadMs": 0.7,
  "responseChars": 12,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-6ccw0-19647",
  "serverAppMs": 0.7,
  "declaredBytes": 12,
  "suppressedSinceLast": 1
}
```

## 2026-11-24T19:48:16.641Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/teams/session/:id/plan",
  "durationMs": 5008.9,
  "fetchMs": 5008.5,
  "responseReadMs": 0.4,
  "responseChars": 25610,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-6ccup-19644",
  "serverAppMs": 1,
  "declaredBytes": 25752,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:46:40.816Z WARN api_request_slow


```json
{
  "requestId": "api-8508-6aa36-19526",
  "method": "GET",
  "route": "/api/sessions/:id/workspace/status",
  "status": 200,
  "durationMs": 1114.9,
  "cpuUserMs": 828,
  "cpuSystemMs": 828,
  "concurrentAtStart": 3,
  "activeAtFinish": 2,
  "declaredResponseBytes": null,
  "rssMiB": 360.6,
  "heapUsedMiB": 112,
  "externalMiB": 67.5,
  "arrayBuffersMiB": 1.5
}
```

## 2026-11-24T19:45:35.438Z WARN client_event_loop_stall


```json
{
  "lagMs": 603.5,
  "usedJsHeapMiB": 202.2,
  "totalJsHeapMiB": 242.2,
  "hardwareConcurrency": 12
}
```

## 2026-11-24T19:45:34.139Z WARN server_event_loop_stall


```json
{
  "lagMs": 650.3,
  "activeRequests": 0,
  "rssMiB": 1106,
  "heapUsedMiB": 227.8,
  "externalMiB": 7.6,
  "arrayBuffersMiB": 0
}
```

## 2026-11-24T19:45:34.131Z WARN api_request_slow


```json
{
  "requestId": "api-8508-68um6-19348",
  "method": "GET",
  "route": "/api/doctor/report",
  "status": 200,
  "durationMs": 1137,
  "cpuUserMs": 1375,
  "cpuSystemMs": 844,
  "concurrentAtStart": 1,
  "activeAtFinish": 0,
  "declaredResponseBytes": null,
  "rssMiB": 1121.7,
  "heapUsedMiB": 227.8,
  "externalMiB": 188.5,
  "arrayBuffersMiB": 0
}
```

## 2026-11-24T19:44:03.097Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/sessions/:id/git-info",
  "durationMs": 7100.3,
  "fetchMs": 6933.5,
  "responseReadMs": 166.8,
  "responseChars": 96,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-66woz-19063",
  "serverAppMs": 303.4,
  "declaredBytes": 96,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:44:03.029Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/tasks/lists/:id",
  "durationMs": 6532.9,
  "fetchMs": 5962,
  "responseReadMs": 570.8,
  "responseChars": 2177,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-66woz-19064",
  "serverAppMs": 8.6,
  "declaredBytes": 2889,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:44:03.029Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/teams/session/:id/plan",
  "durationMs": 6151.9,
  "fetchMs": 5581.3,
  "responseReadMs": 570.5,
  "responseChars": 25610,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-66wp0-19066",
  "serverAppMs": 6.2,
  "declaredBytes": 25752,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:44:03.029Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/sessions/:id/inspection",
  "durationMs": 4531.8,
  "fetchMs": 3961.8,
  "responseReadMs": 570,
  "responseChars": 740,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-66wp0-19067",
  "serverAppMs": 5.6,
  "declaredBytes": 740,
  "suppressedSinceLast": 1
}
```

## 2026-11-24T19:44:03.028Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/session-collaboration/:id/delegation",
  "durationMs": 6149,
  "fetchMs": 5579,
  "responseReadMs": 570,
  "responseChars": 1488,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-66wp0-19065",
  "serverAppMs": 0.9,
  "declaredBytes": 1524,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:43:48.991Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/sessions",
  "durationMs": 4942.7,
  "fetchMs": 4942.3,
  "responseReadMs": 0.4,
  "responseChars": 3710,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-66mcg-19043",
  "serverAppMs": 21.3,
  "declaredBytes": 3838,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:43:48.969Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/teams/session/:id/plan",
  "durationMs": 6077,
  "fetchMs": 6076,
  "responseReadMs": 0.9,
  "responseChars": 25610,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-66mce-19040",
  "serverAppMs": 2.3,
  "declaredBytes": 25752,
  "suppressedSinceLast": 1
}
```

## 2026-11-24T19:43:48.969Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/scheduled-tasks",
  "durationMs": 5062.6,
  "fetchMs": 5062.2,
  "responseReadMs": 0.4,
  "responseChars": 12,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-66mcg-19042",
  "serverAppMs": 0.7,
  "declaredBytes": 12,
  "suppressedSinceLast": 1
}
```

## 2026-11-24T19:43:48.968Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/session-collaboration/:id/delegation",
  "durationMs": 6074.1,
  "fetchMs": 6073.9,
  "responseReadMs": 0.2,
  "responseChars": 1490,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-66mce-19041",
  "serverAppMs": 1.1,
  "declaredBytes": 1526,
  "suppressedSinceLast": 1
}
```

## 2026-11-24T19:43:33.727Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/teams/session/:id/plan",
  "durationMs": 4838.3,
  "fetchMs": 4837.9,
  "responseReadMs": 0.3,
  "responseChars": 25610,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-66al1-19029",
  "serverAppMs": 2,
  "declaredBytes": 25752,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:43:33.726Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/session-collaboration/:id/delegation",
  "durationMs": 4836.2,
  "fetchMs": 4835.5,
  "responseReadMs": 0.6,
  "responseChars": 1490,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-66al2-19030",
  "serverAppMs": 1,
  "declaredBytes": 1526,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:43:16.372Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/sessions",
  "durationMs": 2336.4,
  "fetchMs": 2335.9,
  "responseReadMs": 0.5,
  "responseChars": 3710,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-65x60-18990",
  "serverAppMs": 17.7,
  "declaredBytes": 3838,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:43:16.365Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/teams/session/:id/plan",
  "durationMs": 5480.8,
  "fetchMs": 5473.2,
  "responseReadMs": 7.6,
  "responseChars": 25610,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-65x5z-18987",
  "serverAppMs": 2,
  "declaredBytes": 25752,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:43:16.365Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/scheduled-tasks",
  "durationMs": 2455.1,
  "fetchMs": 2447.7,
  "responseReadMs": 7.4,
  "responseChars": 12,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-65x5z-18988",
  "serverAppMs": 0.3,
  "declaredBytes": 12,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:43:16.365Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/session-collaboration/:id/delegation",
  "durationMs": 5479.9,
  "fetchMs": 5472.8,
  "responseReadMs": 7.1,
  "responseChars": 1488,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-65x5z-18986",
  "serverAppMs": 0.9,
  "declaredBytes": 1524,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:43:16.365Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/tasks/lists/:id",
  "durationMs": 6230.2,
  "fetchMs": 6229.5,
  "responseReadMs": 0.7,
  "responseChars": 2177,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-65x5r-18985",
  "serverAppMs": 2.1,
  "declaredBytes": 2889,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:43:16.332Z WARN client_api_request_failed


```json
{
  "method": "GET",
  "route": "/api/sessions/:id/inspection",
  "durationMs": 6027.4,
  "fetchMs": 6027.3,
  "responseReadMs": 0,
  "responseChars": 0,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "timeoutMs": 6000,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:42:51.662Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/sessions/:id/messages",
  "durationMs": 3291.1,
  "fetchMs": 3085.4,
  "responseReadMs": 205.7,
  "responseChars": 5520669,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-65bp9-18931",
  "serverAppMs": 216.8,
  "declaredBytes": 6447349,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:42:51.633Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/workflows/session-runs/:id",
  "durationMs": 3114.3,
  "fetchMs": 3085.9,
  "responseReadMs": 28.4,
  "responseChars": 11,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-65bl1-18930",
  "serverAppMs": 256.4,
  "declaredBytes": 11,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:42:48.129Z WARN api_request_slow


```json
{
  "requestId": "api-8508-65amk-18919",
  "method": "GET",
  "route": "/api/sessions/:id/workspace/status",
  "status": 200,
  "durationMs": 1009.8,
  "cpuUserMs": 875,
  "cpuSystemMs": 688,
  "concurrentAtStart": 4,
  "activeAtFinish": 1,
  "declaredResponseBytes": null,
  "rssMiB": 358.5,
  "heapUsedMiB": 80.7,
  "externalMiB": 40.6,
  "arrayBuffersMiB": 1.5
}
```

## 2026-11-24T19:42:47.277Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/sessions/:id/git-info",
  "durationMs": 3488.2,
  "fetchMs": 3231.6,
  "responseReadMs": 256.6,
  "responseChars": 96,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-657y7-18910",
  "serverAppMs": 298.4,
  "declaredBytes": 96,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:42:47.277Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/sessions",
  "durationMs": 3504.5,
  "fetchMs": 3248.7,
  "responseReadMs": 255.8,
  "responseChars": 3710,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-657xo-18909",
  "serverAppMs": 7,
  "declaredBytes": 3838,
  "suppressedSinceLast": 1
}
```

## 2026-11-24T19:42:43.611Z WARN client_event_loop_stall


```json
{
  "lagMs": 2527.1,
  "usedJsHeapMiB": 202.2,
  "totalJsHeapMiB": 242.2,
  "hardwareConcurrency": 12
}
```

## 2026-11-24T19:42:37.025Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/sessions",
  "durationMs": 2925.2,
  "fetchMs": 2916.7,
  "responseReadMs": 8.5,
  "responseChars": 3710,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-650kx-18894",
  "serverAppMs": 7.4,
  "declaredBytes": 3838,
  "suppressedSinceLast": 2
}
```

## 2026-11-24T19:42:31.026Z WARN client_event_loop_stall


```json
{
  "lagMs": 1906.2,
  "usedJsHeapMiB": 202.2,
  "totalJsHeapMiB": 242.2,
  "hardwareConcurrency": 12
}
```

## 2026-11-24T19:42:31.017Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/tasks/lists/:id",
  "durationMs": 4359.8,
  "fetchMs": 1459.6,
  "responseReadMs": 2900.1,
  "responseChars": 2177,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-64uu6-18878",
  "serverAppMs": 3.8,
  "declaredBytes": 2889,
  "suppressedSinceLast": 1
}
```

## 2026-11-24T19:42:31.016Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/teams/session/:id/plan",
  "durationMs": 4358.9,
  "fetchMs": 1459,
  "responseReadMs": 2899.9,
  "responseChars": 25610,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-64uu6-18879",
  "serverAppMs": 1.8,
  "declaredBytes": 25752,
  "suppressedSinceLast": 1
}
```

## 2026-11-24T19:42:31.015Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/session-collaboration/:id/delegation",
  "durationMs": 4358,
  "fetchMs": 1458.5,
  "responseReadMs": 2899.5,
  "responseChars": 1527,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-64uu7-18880",
  "serverAppMs": 0.8,
  "declaredBytes": 1563,
  "suppressedSinceLast": 1
}
```

## 2026-11-24T19:42:23.711Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/sessions",
  "durationMs": 2468.9,
  "fetchMs": 2452.4,
  "responseReadMs": 16.5,
  "responseChars": 3710,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-64qnr-18873",
  "serverAppMs": 9.9,
  "declaredBytes": 3838,
  "suppressedSinceLast": 1
}
```

## 2026-11-24T19:42:23.693Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/sessions/:id/inspection",
  "durationMs": 5415.5,
  "fetchMs": 2754.7,
  "responseReadMs": 2660.7,
  "responseChars": 742,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-64odh-18865",
  "serverAppMs": 3.3,
  "declaredBytes": 742,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:42:18.283Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/tasks/lists/:id",
  "durationMs": 3075.5,
  "fetchMs": 193.5,
  "responseReadMs": 2882,
  "responseChars": 2177,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-64m05-18860",
  "serverAppMs": 4.5,
  "declaredBytes": 2889,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:42:18.282Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/teams/session/:id/plan",
  "durationMs": 3075,
  "fetchMs": 193.3,
  "responseReadMs": 2881.7,
  "responseChars": 25610,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-64m05-18862",
  "serverAppMs": 1.8,
  "declaredBytes": 25752,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:42:18.282Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/session-collaboration/:id/delegation",
  "durationMs": 3074.4,
  "fetchMs": 192.9,
  "responseReadMs": 2881.5,
  "responseChars": 1527,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-64m05-18863",
  "serverAppMs": 1.1,
  "declaredBytes": 1563,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:42:18.282Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/scheduled-tasks",
  "durationMs": 3074.4,
  "fetchMs": 193.2,
  "responseReadMs": 2881.2,
  "responseChars": 12,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-64m05-18861",
  "serverAppMs": 0.2,
  "declaredBytes": 12,
  "suppressedSinceLast": 0
}
```

## 2026-11-24T19:42:18.079Z WARN client_event_loop_stall


```json
{
  "lagMs": 1871.4,
  "usedJsHeapMiB": 202.2,
  "totalJsHeapMiB": 242.2,
  "hardwareConcurrency": 12
}
```

## 2026-11-24T19:42:11.429Z WARN client_api_request_slow


```json
{
  "method": "GET",
  "route": "/api/sessions",
  "durationMs": 2244.3,
  "fetchMs": 2237.1,
  "responseReadMs": 7.2,
  "responseChars": 3710,
  "recoveryMs": 0,
  "attempts": 1,
  "recovered": false,
  "status": 200,
  "requestId": "api-8508-64hfo-18846",
  "serverAppMs": 7.7,
  "declaredBytes": 3838,
  "suppressedSinceLast": 2
}
```
